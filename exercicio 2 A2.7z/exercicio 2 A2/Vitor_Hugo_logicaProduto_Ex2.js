// Cálculo de Preço Final de Produto com Desconto Progressivo ex2
function calcularPrecoFinal(precoUnitario, quantidade) {
    const precoTotalItens = precoUnitario * quantidade;
    let desconto = 0;

    if (quantidade < 5) {
        desconto = 0.05;
    } else if (quantidade >= 5 && quantidade < 10) {
        desconto = 0.10;
    } else {
        desconto = 0.15;
    }

    const valorComDesconto = precoTotalItens * (1 - desconto);
    const freteFixo = 15.00;
    const precoFinal = valorComDesconto + freteFixo;

    return precoFinal;
}


function exibirPrecoFinal() {
    const nomeProduto = document.getElementById('nomeProduto').value;
    const precoUnitario = parseFloat(document.getElementById('precoUnitario').value);
    const quantidade = parseInt(document.getElementById('quantidade').value, 10);
    const elementoResultado = document.getElementById('resultadoProduto');

    if (nomeProduto && !isNaN(precoUnitario) && precoUnitario > 0 && !isNaN(quantidade) && quantidade > 0) {
        const precoFinal = calcularPrecoFinal(precoUnitario, quantidade);

        const precoFormatado = precoFinal.toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 });

        elementoResultado.textContent = `O preço final para ${nomeProduto} é de: R$ ${precoFormatado}`;
    } else {
        elementoResultado.textContent = "Por favor, preencha todos os campos corretamente.";
    }
}