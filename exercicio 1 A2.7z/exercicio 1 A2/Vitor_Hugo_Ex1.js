function classificarArray(arr) {

    if (!Array.isArray(arr) || arr.length === 0) {
        return "Outros";
    }

    const todosPositivos = arr.every(n => n > 0);
    const todosNegativos = arr.every(n => n < 0);

    if (todosPositivos) {
        return "Só Positivos";
    } else if (todosNegativos) {
        return "Só Negativos";
    } else {
        return "Outros";
    }

}
console.log(classificarArray([10, 5, 2, 7])); // "Só Positivos"
console.log(classificarArray([0, 3, 0, 1])); // "Outros"
console.log(classificarArray([-4, -1, -9])); // "Só Negativos"
console.log(classificarArray([0, -2, -6, 0])); // "Outros"
console.log(classificarArray([1, -2, 3, -4])); // "Outros"
console.log(classificarArray([1, -2, 0, 4, -5])); // "Outros"
console.log(classificarArray([0, 0, 0])); // "Outros"
console.log(classificarArray([])); // "Outros"